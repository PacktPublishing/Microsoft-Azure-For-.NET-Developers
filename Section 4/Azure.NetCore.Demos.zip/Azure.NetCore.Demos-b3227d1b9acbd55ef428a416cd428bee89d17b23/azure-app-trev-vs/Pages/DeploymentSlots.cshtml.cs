using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace azure_app_trev_vs.Pages
{
    public class DeploymentSlotsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
