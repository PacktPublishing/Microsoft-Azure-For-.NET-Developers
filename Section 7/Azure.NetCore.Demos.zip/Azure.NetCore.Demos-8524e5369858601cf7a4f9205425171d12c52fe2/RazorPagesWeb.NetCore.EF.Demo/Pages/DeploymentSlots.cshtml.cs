using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPagesWeb.NetCore.EF.Demo.Pages
{
    public class DeploymentSlotsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
