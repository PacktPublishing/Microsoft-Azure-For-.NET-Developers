﻿namespace Blazor.AzureCosmosDb.Demo.Data
{
    public class Engineer
    {
        public Guid? id { get; set; }
        public string? Name { get; set; }
        public string? Country { get; set; }
        public string? Specialty { get; set; }
    }
}
